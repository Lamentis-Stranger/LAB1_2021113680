package graph;

public class Edge {
    String target;
    int weight;
    public Edge(String target, int weight) {
        this.target = target;
        this.weight = weight;
    }
}
