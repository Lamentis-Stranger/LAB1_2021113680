package graph;

class Vertex {
    String name;
    int distance;

    Vertex(String name, int distance) {
        this.name = name;
        this.distance = distance;
    }
}